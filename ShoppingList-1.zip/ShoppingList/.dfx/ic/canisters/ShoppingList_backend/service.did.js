export const idlFactory = ({ IDL }) => {
  const Item = IDL.Record({
    'id' : IDL.Nat,
    'name' : IDL.Text,
    'quantity' : IDL.Nat,
    'category' : IDL.Text,
  });
  return IDL.Service({
    'addItem' : IDL.Func([IDL.Text, IDL.Nat, IDL.Opt(IDL.Text)], [IDL.Nat], []),
    'deleteItem' : IDL.Func([IDL.Nat], [IDL.Bool], []),
    'getAllItems' : IDL.Func([], [IDL.Vec(Item)], ['query']),
    'getItem' : IDL.Func([IDL.Nat], [IDL.Opt(Item)], ['query']),
    'getItemsByCategory' : IDL.Func([IDL.Text], [IDL.Vec(Item)], ['query']),
    'updateItem' : IDL.Func(
        [IDL.Nat, IDL.Opt(IDL.Text), IDL.Opt(IDL.Nat), IDL.Opt(IDL.Text)],
        [IDL.Bool],
        [],
      ),
  });
};
export const init = ({ IDL }) => { return []; };
