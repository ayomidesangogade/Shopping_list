import type { Principal } from '@dfinity/principal';
import type { ActorMethod } from '@dfinity/agent';
import type { IDL } from '@dfinity/candid';

export interface Item {
  'id' : bigint,
  'name' : string,
  'quantity' : bigint,
  'category' : string,
}
export interface _SERVICE {
  'addItem' : ActorMethod<[string, bigint, [] | [string]], bigint>,
  'deleteItem' : ActorMethod<[bigint], boolean>,
  'getAllItems' : ActorMethod<[], Array<Item>>,
  'getItem' : ActorMethod<[bigint], [] | [Item]>,
  'getItemsByCategory' : ActorMethod<[string], Array<Item>>,
  'updateItem' : ActorMethod<
    [bigint, [] | [string], [] | [bigint], [] | [string]],
    boolean
  >,
}
export declare const idlFactory: IDL.InterfaceFactory;
export declare const init: (args: { IDL: typeof IDL }) => IDL.Type[];
